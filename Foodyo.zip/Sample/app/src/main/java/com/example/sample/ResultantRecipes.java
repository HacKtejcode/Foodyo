package com.example.sample;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ResultantRecipes extends AppCompatActivity {
    Switch recipeType;
    ListView recipeList;

    int flag = 0;

    private DatabaseReference reference;
    FirebaseFirestore firebaseFirestore;
    CollectionReference collectionReference;

    ArrayList<String> listNames = new ArrayList<>();
    ArrayAdapter<String> adapter;


    ArrayList<String> rImg = new ArrayList<>();
    RecipeData rd;
    ImageView imageView;
    TextView recipeText;
    StorageReference mStorageReference;
    ArrayList<String> checkList = new ArrayList<>();
    List<String> ingredientsList = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultant_recipes);
        recipeType = (Switch) findViewById(R.id.vns);
        recipeList = (ListView) findViewById(R.id.listViewRecipe);
        imageView = (ImageView) findViewById(R.id.r_img);
        recipeText = (TextView) findViewById(R.id.r_title);
        rd = new RecipeData();
        Bundle b = getIntent().getExtras();
        checkList = b.getStringArrayList("code");
        Collections.sort(checkList);
        Toast.makeText(ResultantRecipes.this, "Select Recipe Type", Toast.LENGTH_LONG).show();


        reference = FirebaseDatabase.getInstance().getReference("Recipes");
        firebaseFirestore = FirebaseFirestore.getInstance();
        collectionReference = firebaseFirestore.collection("main");
        adapter = new ArrayAdapter<>(this,R.layout.recipelist,R.id.r_title,listNames);


        recipeType.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    recipeType.setText("Veg");
                    reference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            listNames.clear();
                            for (DataSnapshot ds : snapshot.getChildren()) {
                                rd = ds.getValue(RecipeData.class);
                                if (!(rd == null)) {
                                    if ("veg".equals(rd.getType())) {

                                        loadIngredients();

                                        Collections.sort(ingredientsList);
                                        if (!(checkList.isEmpty())) {
                                            for (int i = 0; i <= ingredientsList.size(); i++) {
                                                if (checkPresenceIncheckList(ingredientsList.get(i))) {
                                                    flag = 1;
                                                } else {
                                                    flag = 0;
                                                    break;
                                                }

                                            }
                                            if (flag == 1) {
                                                listNames.add(rd.getrName());
                                            }
                                        } else {
                                            listNames.add(rd.getrName());
                                        }

                                        adapter.notifyDataSetChanged();
                                    }
                                }
                            }

                            recipeList.setAdapter(adapter);


                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(ResultantRecipes.this, "That did not work.", Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    recipeType.setText("Non-Veg");
                    reference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            listNames.clear();

                            for (DataSnapshot ds : snapshot.getChildren()) {
                                rd = ds.getValue(RecipeData.class);
                                if (!(rd == null)) {
                                    if ("non-veg".equals(rd.getType())) {

                                        loadIngredients();

                                        Collections.sort(ingredientsList);
                                        Toast.makeText(ResultantRecipes.this, "ingredientList: " + ingredientsList, Toast.LENGTH_SHORT).show();
                                        if (!(checkList.isEmpty())) {
                                            for (int i = 0; i <= ingredientsList.size(); i++) {
                                                if (checkPresenceIncheckList(ingredientsList.get(i))) {
                                                    flag = 1;
                                                } else {
                                                    flag = 0;
                                                    break;
                                                }

                                            }
                                            if (flag == 1) {
                                                listNames.add(rd.getrName());
                                            }
                                        } else {
                                            listNames.add(rd.getrName());
                                        }
                                        adapter.notifyDataSetChanged();
                                    }
                                }
                            }

                            recipeList.setAdapter(adapter);


                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(ResultantRecipes.this, "That did not work.", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });




        recipeList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(ResultantRecipes.this,RecipeDetails.class);
                intent.putExtra("name", listNames.get(i));
                startActivity(intent);

            }
        });
    }

    public void loadIngredients() {
        collectionReference.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                String code;
                for(QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                    RecipeData recipeData = documentSnapshot.toObject(RecipeData.class);
                    code = recipeData.getCode();
                    for(String ing : recipeData.getIngs()) {
                        ingredientsList.add(ing);
                    }
                }
            }
        });
    }

    public boolean checkPresenceIncheckList(String ing) {
        for(int k = 0; k < checkList.size(); k++) {
            if (ing.equals(checkList.get(k))) {
                return true;
            }
        }
        return false;
    }
}