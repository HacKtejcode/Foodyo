package com.example.sample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Rating;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FeedbackPage extends AppCompatActivity {
    TextView title;
    ImageView image;
    RatingBar rb;
    EditText writtenFB;
    Button submit;
    float rate;
    float totalStars;
    String recipeName;
    String email;
    String textFeedback;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback_page);

        title = (TextView) findViewById(R.id.fTitle);
        image = (ImageView) findViewById(R.id.fImg);
        rb = (RatingBar) findViewById(R.id.frb);
        writtenFB = (EditText) findViewById(R.id.fEdit);
        submit = (Button) findViewById(R.id.save);

        title.setGravity(1);
        title.setTextSize(22);
        title.setSingleLine(true);

        databaseReference = FirebaseDatabase.getInstance().getReference("Feedback");
        SessionManagement sessionManagement = new SessionManagement(FeedbackPage.this);
        email = sessionManagement.getSession();
        Bundle msg = getIntent().getExtras();
        recipeName = msg.getString("id");
        title.setText(recipeName);

        totalStars=rb.getNumStars();




        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SaveFeedback();
            }
        });

    }

    private void SaveFeedback() {

        rate=rb.getRating();
        textFeedback = writtenFB.getText().toString();
        FeedbackData feedbackData = new FeedbackData(email,rate,recipeName,textFeedback);
        String FeedbackUploadId = databaseReference.push().getKey();
        databaseReference.child(FeedbackUploadId).setValue(feedbackData).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()) {
                    Toast.makeText(FeedbackPage.this, "Feedback Saved Successfully.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(FeedbackPage.this, "Something went wrong. Try Again!!", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}