package com.example.sample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Feedback extends AppCompatActivity {
    Switch recipeType;
    ListView recipeList;
    private DatabaseReference reference;
    ArrayList<String> listNames = new ArrayList<>();
    ArrayAdapter<String> adapter;
    RecipeData rd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        recipeType = (Switch) findViewById(R.id.sw);
        recipeList = (ListView) findViewById(R.id.recipeLV);
        rd = new RecipeData();
        Toast.makeText(Feedback.this, "Select Recipe Type", Toast.LENGTH_LONG).show();

        reference = FirebaseDatabase.getInstance().getReference("Recipes");

        adapter = new ArrayAdapter<String>(this,R.layout.recipelist,R.id.r_title,listNames);

        recipeType.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b == true) {
                    recipeType.setText("Veg");
                    reference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                            listNames.clear();
                            for (DataSnapshot ds : snapshot.getChildren()) {
                                rd = ds.getValue(RecipeData.class);
                                if ("veg".equals(rd.type)) {
                                    listNames.add(rd.getrName());
                                    adapter.notifyDataSetChanged();
                                }
                            }
                            recipeList.setAdapter(adapter);


                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(Feedback.this, "That did not work.", Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    recipeType.setText("Non-Veg");
                    reference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                            listNames.clear();
                            for (DataSnapshot ds : snapshot.getChildren()) {
                                rd = ds.getValue(RecipeData.class);
                                if ("non-veg".equals(rd.type)) {
                                    listNames.add(rd.getrName());
                                    adapter.notifyDataSetChanged();
                                }
                            }

                            recipeList.setAdapter(adapter);


                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(Feedback.this, "That did not work.", Toast.LENGTH_LONG).show();
                        }
                    });

                }






            }
        });

        recipeList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                Intent intent = new Intent(Feedback.this,FeedbackPage.class);
                intent.putExtra("id", listNames.get(i));
                startActivity(intent);

            }
        });
    }
}