package com.example.sample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Pattern;

public class Registration extends AppCompatActivity implements View.OnClickListener{
    private FirebaseAuth mAuth;

    TextView heading;
    EditText name, email, pass, confirmPass;
    Button register;
    ProgressBar bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        heading = (TextView) findViewById(R.id.textView);
        name = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        pass = (EditText) findViewById(R.id.pass);
        confirmPass = (EditText) findViewById(R.id.confirmPass);
        bar = (ProgressBar) findViewById(R.id.rbar);
        register = (Button) findViewById(R.id.reg);
        heading.setOnClickListener(this::onClick);
        register.setOnClickListener(this::onClick);
        mAuth = FirebaseAuth.getInstance();

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textView:
                startActivity(new Intent(this, LandingPage.class));
                break;
            case R.id.reg:
                registerUser();
                //startActivity(new Intent(this, Login.class));
                break;
        }

    }

    private void registerUser() {
        String fullName = name.getText().toString().trim();
        String Email = email.getText().toString().trim();
        String Pass = pass.getText().toString().trim();
        String ConfirmPass = confirmPass.getText().toString().trim();

        if(fullName.isEmpty()) {
            name.setError("Full Name is required");
            name.requestFocus();
            return;
        }
        if(Email.isEmpty()) {
            email.setError("Email is required");
            email.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            email.setError("Please provide a valid email.");
            email.requestFocus();
            return;
        }
        if(Pass.isEmpty()) {
            pass.setError("Password is required");
            pass.requestFocus();
            return;
        }
        if(Pass.length() < 6 || Pass.length() > 15) {
            pass.setError("Password length must be 6-15 characters");
            pass.requestFocus();
            return;
        }
        if(ConfirmPass.isEmpty()) {
            confirmPass.setError("Confirm Password is required");
            confirmPass.requestFocus();
            return;
        }
        if(!Pass.equals(ConfirmPass)) {
            confirmPass.setError("Confirm Password does not match with the Password");
            confirmPass.requestFocus();
            return;
        }

        bar.setVisibility(View.VISIBLE);


        mAuth.createUserWithEmailAndPassword(Email,Pass)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    user user = new user(fullName, Email, Pass);

                    FirebaseDatabase.getInstance().getReference("users")
                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()) {
                                Toast.makeText(Registration.this, "Registered Successfully", Toast.LENGTH_LONG).show();
                                //bar.setVisibility(View.VISIBLE);
                                startActivity(new Intent(Registration.this, Login.class));
                            } else {
                                Toast.makeText(Registration.this, "Registration Failed!! Please Try Again!", Toast.LENGTH_LONG).show();
                                bar.setVisibility(View.GONE);
                            }
                        }
                    });
                } else {
                    Toast.makeText(Registration.this, "Registration Failed!! Please Try Again.", Toast.LENGTH_LONG).show();
                    bar.setVisibility(View.GONE);
                }
            }
        });
    }
}