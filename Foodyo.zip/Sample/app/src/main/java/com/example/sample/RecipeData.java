package com.example.sample;

import java.sql.Time;
import java.util.List;

public class RecipeData {
    String rName;
    String code;
    String time;
    int no_of_ig;
    String type;
    String igNAmt;
    String steps;
    String link;
    String imageUrl;
    List<String> ings;

    public RecipeData() {
    }

    public RecipeData(String rName, String code, String type, List<String> ings) {
        this.rName = rName;
        this.code = code;
        this.type = type;
        this.ings = ings;
    }

    public RecipeData(String rName, String code, String time, int no_of_ig, String type, String igNAmt, String steps, String link, String imageUrl, List<String> ings) {
        this.rName = rName;
        this.code = code;
        this.time = time;
        this.no_of_ig = no_of_ig;
        this.type = type;
        this.igNAmt = igNAmt;
        this.steps = steps;
        this.link = link;
        this.imageUrl = imageUrl;
        this.ings = ings;
    }

    public String getrName() {
        return rName;
    }

    public void setrName(String rName) {
        this.rName = rName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getNo_of_ig() {
        return no_of_ig;
    }

    public void setNo_of_ig(int no_of_ig) {
        this.no_of_ig = no_of_ig;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIgNAmt() {
        return igNAmt;
    }

    public void setIgNAmt(String igNAmt) {
        this.igNAmt = igNAmt;
    }

    public String getSteps() {
        return steps;
    }

    public void setSteps(String steps) {
        this.steps = steps;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public List<String> getIngs() {
        return ings;
    }

    public void setIngs(List<String> ings) {
        this.ings = ings;
    }
}
