package com.example.sample;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class IngredientsFragment extends Fragment {
    CheckBox potato, tomato, peas, cauliflower, cabbage, spinach, onion, ladyfinger,
            beans, sprouts, carrot, eggplant, haldi, corianderLeaves, gobi, matar;
    DatabaseReference reference;
    Button searchRecipes;
    ArrayList<String> checkList = new ArrayList<>();
    List<String> ingredients = new ArrayList<>();
    List<String> resultRecipes = new ArrayList<>();
    boolean flag = false;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_ingredients, container, false);
        potato = view.findViewById(R.id.potato);
        tomato = view.findViewById(R.id.tomato);
        peas = view.findViewById(R.id.peas);
        cauliflower = view.findViewById(R.id.cauliflower);
        cabbage = view.findViewById(R.id.cabbage);
        spinach = view.findViewById(R.id.spinach);
        onion = view.findViewById(R.id.onion);
        ladyfinger = view.findViewById(R.id.ladyfinger);
        beans = view.findViewById(R.id.beans);
        sprouts = view.findViewById(R.id.sprouts);
        carrot = view.findViewById(R.id.carrot);
        eggplant = view.findViewById(R.id.eggplant);
        haldi = view.findViewById(R.id.haldi);
        corianderLeaves = view.findViewById(R.id.corianderLeaves);
        gobi = view.findViewById(R.id.gobi);
        matar = view.findViewById(R.id.matar);
        searchRecipes = view.findViewById(R.id.searchRecipes);

        potato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (potato.isChecked()) {
                    checkList.add("potato");
                } else {
                    checkList.remove("potato");
                }
            }
        });

        tomato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (tomato.isChecked()) {
                    checkList.add("tomato");
                } else {
                    checkList.remove("tomato");
                }
            }
        });

        peas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (peas.isChecked()) {
                    checkList.add("peas");
                } else {
                    checkList.remove("peas");
                }
            }
        });

        cauliflower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cauliflower.isChecked()) {
                    checkList.add("cauliflower");
                } else {
                    checkList.remove("cauliflower");
                }
            }
        });

        cabbage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cabbage.isChecked()) {
                    checkList.add("cabbage");
                } else {
                    checkList.remove("cabbage");
                }
            }
        });

        spinach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (spinach.isChecked()) {
                    checkList.add("spinach");
                } else {
                    checkList.remove("spinach");
                }
            }
        });

        onion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onion.isChecked()) {
                    checkList.add("onion");
                } else {
                    checkList.remove("onion");
                }
            }
        });

        ladyfinger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ladyfinger.isChecked()) {
                    checkList.add("ladyfinger");
                } else {
                    checkList.remove("ladyfinger");
                }
            }
        });

        beans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (beans.isChecked()) {
                    checkList.add("beans");
                } else {
                    checkList.remove("beans");
                }
            }
        });

        sprouts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sprouts.isChecked()) {
                    checkList.add("sprouts");
                } else {
                    checkList.remove("sprouts");
                }
            }
        });

        carrot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (carrot.isChecked()) {
                    checkList.add("carrot");
                } else {
                    checkList.remove("carrot");
                }
            }
        });

        eggplant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eggplant.isChecked()) {
                    checkList.add("eggplant");
                } else {
                    checkList.remove("eggplant");
                }
            }
        });

        haldi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (haldi.isChecked()) {
                    checkList.add("haldi");
                } else {
                    checkList.remove("haldi");
                }
            }
        });

        corianderLeaves.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (corianderLeaves.isChecked()) {
                    checkList.add("corianderleaves");
                } else {
                    checkList.remove("corianderleaves");
                }
            }
        });

        gobi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (gobi.isChecked()) {
                    checkList.add("gobi");
                } else {
                    checkList.remove("gobi");
                }
            }
        });

        matar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (matar.isChecked()) {
                    checkList.add("matar");
                } else {
                    checkList.remove("matar");
                }
            }
        });

        reference = FirebaseDatabase.getInstance().getReference("Recipes");
        Collections.sort(checkList);


        searchRecipes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //CompareBothLists();
                MoveToResultantRecipes();
            }
        });



        return view;
    }
    //String[] a = (String[]) checkList.toArray();
    //String code = a.toString();

    public void CompareBothLists() {
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ds: snapshot.getChildren()) {
                    RecipeData data = ds.getValue(RecipeData.class);

                    for(String d: data.getIngs()) {
                        ingredients.add(d);
                    }
                    //ingredients.remove(0);
                    Collections.sort(ingredients);

                    if (checkList.equals(ingredients)) {
                        resultRecipes.add(data.getCode());
                        flag = false;
                    } else {
                        resultRecipes.remove(data.getCode());
                        flag = false;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Something went wrong!!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void MoveToResultantRecipes() {
        Intent intent = new Intent(getActivity(), ResultantRecipes.class);
        intent.putExtra("code", checkList);
        startActivity(intent);

    }


}
