package com.example.sample;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class CustomRecipe extends ArrayAdapter {
    private ArrayList<String> r_names;
    private ArrayList<String> img_id;
    private Activity context;

    CustomRecipe(Activity context, ArrayList<String> r_names, ArrayList<String> img_id) {
        super(context, R.layout.recipelist, r_names);
        this.context=context;
        this.r_names=r_names;
        this.img_id =img_id;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v=convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        if(convertView==null)
            v = inflater.inflate(R.layout.recipelist, null, true);
        TextView txt = (TextView) v.findViewById(R.id.r_title);
        ImageView img = (ImageView) v.findViewById(R.id.r_img);

        txt.setText((CharSequence) r_names.get(position));
        img.setImageResource(Integer.parseInt(img_id.get(position)));
        return  v;
    }
}
