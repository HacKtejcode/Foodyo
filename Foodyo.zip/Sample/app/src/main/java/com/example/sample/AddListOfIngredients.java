package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class AddListOfIngredients extends AppCompatActivity {
    EditText arrayOfIng;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_list_of_ingredients);
        arrayOfIng = (EditText) findViewById(R.id.listOfIng);
        submit = (Button) findViewById(R.id.submit);
    }
}