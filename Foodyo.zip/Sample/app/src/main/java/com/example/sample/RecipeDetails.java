package com.example.sample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RecipeDetails extends AppCompatActivity {
    TextView heading, timeTV, inNAmtTV, stepsTV, linkTV;
    DatabaseReference reference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_details);
        heading = (TextView) findViewById(R.id.title);
        timeTV = (TextView) findViewById(R.id.time);
        inNAmtTV = (TextView) findViewById(R.id.inNAmt);
        stepsTV = (TextView) findViewById(R.id.r_steps);
        linkTV = (TextView) findViewById(R.id.vLink);
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        heading.setText(name);

        reference = FirebaseDatabase.getInstance().getReference("Recipes");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ds: snapshot.getChildren()) {
                    RecipeData data = ds.getValue(RecipeData.class);
                    if (name.equals(data.rName)) {


                        String time = data.time;
                        String igNAmt = data.igNAmt;
                        String steps = data.steps;
                        String link = data.link;

                        timeTV.setText("Preparation Time : " + time + " minutes");
                        inNAmtTV.setText("Ingredients and Amount \n" + igNAmt);
                        stepsTV.setText("Steps to prepare the dish \n" + steps);
                        linkTV.setText("Refer to the video link for better preparation : " + link);



                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(RecipeDetails.this, "Something went wrong!!", Toast.LENGTH_LONG).show();
            }
        });
    }
}